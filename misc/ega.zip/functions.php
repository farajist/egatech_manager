<?php 
	 include('config.php');
	function show_clients ($clients) {
		$text = "\n\t<ul>\n";
		foreach ($clients as $key => $value) {
			// echo "Key is : ". print_r($key)."\t Values is : ".print_r($value); 
			$text .= "\t\t";
			$text .= '<li><a href="client_detail.php?id='.$key.'">'.$value["client_name"].'</a></li>';
			$text .= "\n";
		}
		$text .= "</ul>";
		return $text;
	}

	function get_clients($cn){
		$query = "SELECT client_id, client_code, client_name, address, phone, email FROM Client";
		$clients = array();
		if ($result = execute_query($cn, $query)) {
		    while ($row = $result->fetch_assoc()) {
			    $clients[$row['client_id']]['client_code'] = $row['client_code'];
			    $clients[$row['client_id']]['client_name'] = $row['client_name'];
			    $clients[$row['client_id']]['address'] = $row['address'];
			    $clients[$row['client_id']]['phone'] = $row['phone'];
			    $clients[$row['client_id']]['email'] = $row['email'];
		    }
		    $result->free();
		}
		return $clients;
	}

	function get_connection() {
		global $db_hostname, $db_username, $db_password, $db_database;

		$connection = new mysqli($db_hostname, $db_username, $db_password, $db_database);
		if($connection->connect_error) die($connection->connect_error);
			return $connection;
	}

	function execute_query($cn, $query) {
		if ($result = $cn->query($query))
			return $result;
		return null;
	}

	// function sanistize_string($var)
	// {
	// 	$var = stripcslashes($var);
	// 	$var = htmlentities($var);
	// 	$var = strip_tags($var);
	// 	return $var;
	// }

	// //Epuration des elements SQL 
	// function sanitizeMySQL($cnx, $var)
	// {
	// 	$var = $cnx->real_escape_string($var);
	// 	$var = sanistize_string($var);
	// 	return $var;
	// }

	function render_it($cn) {
		$html_text = '<!DOCTYPE html>
		<html>
		<head>
			<title>Subscribe to our website !</title>
			<link rel="stylesheet" type="text/css" href="lib/w3.css">
			<meta charset="utf-8">

		</head>
		<body>';
		$clts = get_clients($cn);

		$html_text .= show_clients($clts);

		$html_text .= '</body></html>';
		return $html_text;
	}

	$cn = get_connection();
	echo render_it($cn);
	$cn->close();
?>