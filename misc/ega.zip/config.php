<?php
	global $db_hostname, $db_username, $db_password, $db_database;

	$db_hostname = "localhost";
	$db_username = "root";
	$db_password = "CStar.hdb07_mysql";
	$db_database = "Egatech";
?>