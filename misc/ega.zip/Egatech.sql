-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 02, 2017 at 12:23 AM
-- Server version: 5.7.17
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Egatech`
--

-- --------------------------------------------------------

--
-- Table structure for table `CLIENT`
--

CREATE TABLE `CLIENT` (
  `CLIENT_ID` int(11) NOT NULL,
  `CLIENT_CODE` varchar(10) DEFAULT NULL,
  `CLIENT_NAME` varchar(40) DEFAULT NULL,
  `ADDRESS` text,
  `PHONE` varchar(13) DEFAULT NULL,
  `EMAIL` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `CLIENT`
--

INSERT INTO `CLIENT` (`CLIENT_ID`, `CLIENT_CODE`, `CLIENT_NAME`, `ADDRESS`, `PHONE`, `EMAIL`) VALUES
(1, '003', 'SICOMEK', NULL, NULL, NULL),
(2, '004', 'LAFARGE', NULL, NULL, NULL),
(3, '005', 'SIMAFLEX', NULL, NULL, NULL),
(4, '006', 'YAZAKI', NULL, NULL, NULL),
(5, '007', 'DELPHI', NULL, NULL, NULL),
(6, '001', 'SIPAT', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `COMMANDE`
--

CREATE TABLE `COMMANDE` (
  `CMD_ID` int(11) NOT NULL,
  `CLIENT_ID` int(11) DEFAULT NULL,
  `PM_ID` int(11) NOT NULL,
  `NUM_CMD` int(11) DEFAULT NULL,
  `DATE` date DEFAULT NULL,
  `TOTAL_HT` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `COMMANDLINE`
--

CREATE TABLE `COMMANDLINE` (
  `CMD_LINE_ID` int(11) NOT NULL,
  `CMD_ID` int(11) NOT NULL,
  `PRODUCT_ID` int(11) NOT NULL,
  `CMD_LINE_NUM` int(11) DEFAULT NULL,
  `QTE` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `PAYMENTMODE`
--

CREATE TABLE `PAYMENTMODE` (
  `PM_ID` int(11) NOT NULL,
  `PM_DESC` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `PRODUCT`
--

CREATE TABLE `PRODUCT` (
  `PRODUCT_ID` int(11) NOT NULL,
  `PRODUCT_REF` varchar(20) DEFAULT NULL,
  `DESIGNATION` varchar(100) DEFAULT NULL,
  `UNIT_PRICE` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ROLE`
--

CREATE TABLE `ROLE` (
  `ROLE_ID` int(11) NOT NULL,
  `ROLE_NAME` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ROLE`
--

INSERT INTO `ROLE` (`ROLE_ID`, `ROLE_NAME`) VALUES
(1, 'Admin'),
(2, 'Secretaire');

-- --------------------------------------------------------

--
-- Table structure for table `USER`
--

CREATE TABLE `USER` (
  `_ID` int(11) NOT NULL,
  `ROLE_ID` int(11) NOT NULL,
  `USERNAME` varchar(60) DEFAULT NULL,
  `PASSWORD` varchar(256) DEFAULT NULL,
  `ACTIVE` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `USER`
--

INSERT INTO `USER` (`_ID`, `ROLE_ID`, `USERNAME`, `PASSWORD`, `ACTIVE`) VALUES
(1, 1, 'admin', 'fc76eb183da288d9e92aba94eecc0dea5e461d0b', 1),
(2, 2, 'user', '707634ff4e82f04f892436889bdc693174a103a7', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `CLIENT`
--
ALTER TABLE `CLIENT`
  ADD PRIMARY KEY (`CLIENT_ID`);

--
-- Indexes for table `COMMANDE`
--
ALTER TABLE `COMMANDE`
  ADD PRIMARY KEY (`CMD_ID`),
  ADD KEY `FK_AVOIR` (`PM_ID`),
  ADD KEY `FK_EFFECTUER` (`CLIENT_ID`);

--
-- Indexes for table `COMMANDLINE`
--
ALTER TABLE `COMMANDLINE`
  ADD PRIMARY KEY (`CMD_LINE_ID`),
  ADD KEY `FK_CONTENIR` (`CMD_ID`),
  ADD KEY `FK_SE_COMPOSER` (`PRODUCT_ID`);

--
-- Indexes for table `PAYMENTMODE`
--
ALTER TABLE `PAYMENTMODE`
  ADD PRIMARY KEY (`PM_ID`);

--
-- Indexes for table `PRODUCT`
--
ALTER TABLE `PRODUCT`
  ADD PRIMARY KEY (`PRODUCT_ID`);

--
-- Indexes for table `ROLE`
--
ALTER TABLE `ROLE`
  ADD PRIMARY KEY (`ROLE_ID`);

--
-- Indexes for table `USER`
--
ALTER TABLE `USER`
  ADD PRIMARY KEY (`_ID`),
  ADD KEY `FK_JOUER` (`ROLE_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `CLIENT`
--
ALTER TABLE `CLIENT`
  MODIFY `CLIENT_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `COMMANDE`
--
ALTER TABLE `COMMANDE`
  MODIFY `CMD_ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `COMMANDLINE`
--
ALTER TABLE `COMMANDLINE`
  MODIFY `CMD_LINE_ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `PAYMENTMODE`
--
ALTER TABLE `PAYMENTMODE`
  MODIFY `PM_ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `PRODUCT`
--
ALTER TABLE `PRODUCT`
  MODIFY `PRODUCT_ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ROLE`
--
ALTER TABLE `ROLE`
  MODIFY `ROLE_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `USER`
--
ALTER TABLE `USER`
  MODIFY `_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `COMMANDE`
--
ALTER TABLE `COMMANDE`
  ADD CONSTRAINT `FK_AVOIR` FOREIGN KEY (`PM_ID`) REFERENCES `PAYMENTMODE` (`PM_ID`),
  ADD CONSTRAINT `FK_EFFECTUER` FOREIGN KEY (`CLIENT_ID`) REFERENCES `CLIENT` (`CLIENT_ID`);

--
-- Constraints for table `COMMANDLINE`
--
ALTER TABLE `COMMANDLINE`
  ADD CONSTRAINT `FK_CONTENIR` FOREIGN KEY (`CMD_ID`) REFERENCES `COMMANDE` (`CMD_ID`),
  ADD CONSTRAINT `FK_SE_COMPOSER` FOREIGN KEY (`PRODUCT_ID`) REFERENCES `PRODUCT` (`PRODUCT_ID`);

--
-- Constraints for table `USER`
--
ALTER TABLE `USER`
  ADD CONSTRAINT `FK_JOUER` FOREIGN KEY (`ROLE_ID`) REFERENCES `ROLE` (`ROLE_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
